﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.Interfaces;

namespace WebApplication3.Services
{
    public class NumManipulator : INumManipulator
    {
        private ILogger<NumManipulator> _logger;
        public NumManipulator(ILogger<NumManipulator> logger)
        {
            _logger = logger;
        }

        public async Task<IEnumerable<int>> GetCommonValues(IFormFile formFile)
        {

            List<int> numList = new List<int>();

            try
            {
                using (StreamReader sr = new StreamReader(formFile.OpenReadStream()))
                {
                    string line;
                    while ((line = await sr.ReadLineAsync()) != null)
                    {
                        if (int.TryParse(line, out int num))
                        {
                            numList.Add(num);
                        }
                    }
                }

                var q = numList.GroupBy(x => x)
                                .Select(g => new { Value = g.Key, Count = g.Count() })
                                .OrderByDescending(x => x.Count)
                                .Take(5)
                                .Select(x => x.Value);
                return q;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception {ex} thrown");
                throw ex;
            }
        }
    }
}
