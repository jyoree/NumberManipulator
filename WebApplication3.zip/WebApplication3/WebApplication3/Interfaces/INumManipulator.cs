﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication3.Interfaces
{
    public interface INumManipulator
    {
        Task<IEnumerable<int>> GetCommonValues(IFormFile formFile);
    }
}
