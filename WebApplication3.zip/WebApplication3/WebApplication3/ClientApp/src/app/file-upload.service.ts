import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

  constructor(private httpClient: HttpClient) { }

  postFile(fileToUpload: File): Observable<number[]> {
    const endpoint = 'api/numManipulator/mostcommon';
    let httpHeaders = new HttpHeaders();
    httpHeaders = httpHeaders.set('Accept', 'application/json');
    httpHeaders.append('Content-Type', 'multipart/form-data')
    const options = { headers: httpHeaders };
    const formData: FormData = new FormData();
    formData.append('File', fileToUpload);
    formData.append('FileName', fileToUpload.name);
    return this.httpClient.post<number[]>(endpoint, formData, options);
  }
}
