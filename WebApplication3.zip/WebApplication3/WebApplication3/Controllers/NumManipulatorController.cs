﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApplication3.Interfaces;
using WebApplication3.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication3.Controllers
{
    [Route("api/numManipulator")]
    [ApiController]
    public class NumManipulatorController : ControllerBase
    {
        ILogger<NumManipulatorController> _logger;
        INumManipulator _numManipulator;
        public NumManipulatorController(INumManipulator numManipulator, ILogger<NumManipulatorController> logger)
        {
            _numManipulator = numManipulator;
            _logger = logger;
        }
      
        [HttpPost("mostcommon")]
        public async Task<IActionResult> GetMostCommon([FromForm]FileData fileData)
        {
            if (fileData?.File == null)
                return BadRequest("No file uploaded");
            try
            {
                var res = await _numManipulator.GetCommonValues(fileData.File);
                return Ok(res);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception {ex} thrown for {fileData?.FileName}");
                return StatusCode(500, ex);
            }
            
        }
    }
}
